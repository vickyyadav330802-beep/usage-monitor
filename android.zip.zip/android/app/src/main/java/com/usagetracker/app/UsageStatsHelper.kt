package com.usagetracker.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Process
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class UsageSession(
    val id: String,
    val startTime: Long,
    val endTime: Long,
    val durationMs: Long
)

data class AppUsageItem(
    val packageName: String,
    val appName: String,
    val iconBase64: String?,
    val totalForegroundTimeMs: Long,
    val lastTimeUsedMs: Long,
    val firstTimeUsedMs: Long,
    val launchCount: Int,
    val sessions: List<UsageSession>
)

data class DayUsageData(
    val dateString: String,
    val dayLabel: String,
    val totalScreenTimeMs: Long,
    val totalAppsUsed: Int,
    val mostUsedApp: AppUsageItem?,
    val apps: List<AppUsageItem>
)

data class TopAppSummary(
    val appName: String,
    val packageName: String,
    val durationMs: Long
)

data class HistoryDaySummary(
    val dateString: String,
    val dayLabel: String,
    val totalScreenTimeMs: Long,
    val topApps: List<TopAppSummary>
)

object UsageStatsHelper {

    /**
     * Checks if the user has granted PACKAGE_USAGE_STATS permission in System Settings.
     */
    fun hasUsageAccessPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Obtains start and end timestamp for a specific day offset (0 = today, 1 = yesterday, etc.)
     */
    fun getDayRange(daysAgo: Int): Pair<Long, Long> {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
        
        // Start of Day (00:00:00.000)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startTime = calendar.timeInMillis

        // End of Day (23:59:59.999 or now if today)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endOfDay = calendar.timeInMillis

        val now = System.currentTimeMillis()
        val endTime = if (daysAgo == 0) minOf(now, endOfDay) else endOfDay

        return Pair(startTime, endTime)
    }

    /**
     * Parses real UsageEvents to reconstruct discrete foreground usage sessions.
     */
    fun getUsageForDay(context: Context, daysAgo: Int): DayUsageData {
        val (startTime, endTime) = getDayRange(daysAgo)
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return createEmptyDayData(startTime, daysAgo)

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()

        // Track per-package active open timestamps and completed sessions
        val packageOpenTime = mutableMapOf<String, Long>()
        val packageSessions = mutableMapOf<String, MutableList<UsageSession>>()
        val packageLaunchCounts = mutableMapOf<String, Int>()
        val packageLastUsed = mutableMapOf<String, Long>()
        val packageFirstUsed = mutableMapOf<String, Long>()

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            val pkg = event.packageName ?: continue
            val eventTime = event.timeStamp

            // Filter out internal system UI and launcher noise if needed
            if (pkg == "com.android.systemui") continue

            when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED,
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    packageOpenTime[pkg] = eventTime
                    packageLaunchCounts[pkg] = (packageLaunchCounts[pkg] ?: 0) + 1
                    if (!packageFirstUsed.containsKey(pkg)) {
                        packageFirstUsed[pkg] = eventTime
                    }
                    packageLastUsed[pkg] = eventTime
                }
                UsageEvents.Event.ACTIVITY_PAUSED,
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    val openedAt = packageOpenTime.remove(pkg)
                    if (openedAt != null && eventTime > openedAt) {
                        val duration = eventTime - openedAt
                        if (duration > 500) { // filter micro-ticks < 500ms
                            val sessions = packageSessions.getOrPut(pkg) { mutableListOf() }
                            sessions.add(
                                UsageSession(
                                    id = "$pkg-${sessions.size}-$openedAt",
                                    startTime = openedAt,
                                    endTime = eventTime,
                                    durationMs = duration
                                )
                            )
                        }
                    }
                    packageLastUsed[pkg] = eventTime
                }
            }
        }

        // Close any ongoing session at query time if it occurred during the interval
        for ((pkg, openedAt) in packageOpenTime) {
            if (endTime > openedAt) {
                val duration = endTime - openedAt
                if (duration > 500) {
                    val sessions = packageSessions.getOrPut(pkg) { mutableListOf() }
                    sessions.add(
                        UsageSession(
                            id = "$pkg-${sessions.size}-$openedAt",
                            startTime = openedAt,
                            endTime = endTime,
                            durationMs = duration
                        )
                    )
                }
            }
        }

        // Package manager to resolve real app names and icons
        val pm = context.packageManager
        val appItems = mutableListOf<AppUsageItem>()
        var totalScreenTime = 0L

        for ((pkg, sessions) in packageSessions) {
            val totalTime = sessions.sumOf { it.durationMs }
            if (totalTime < 1000) continue // Skip under 1 second of total usage

            totalScreenTime += totalTime
            val appName = getAppName(pm, pkg)
            val iconBase64 = getAppIconBase64(pm, pkg)
            val lastUsed = packageLastUsed[pkg] ?: sessions.lastOrNull()?.endTime ?: startTime
            val firstUsed = packageFirstUsed[pkg] ?: sessions.firstOrNull()?.startTime ?: startTime
            val launches = packageLaunchCounts[pkg] ?: sessions.size

            appItems.add(
                AppUsageItem(
                    packageName = pkg,
                    appName = appName,
                    iconBase64 = iconBase64,
                    totalForegroundTimeMs = totalTime,
                    lastTimeUsedMs = lastUsed,
                    firstTimeUsedMs = firstUsed,
                    launchCount = launches,
                    sessions = sessions.sortedByDescending { it.startTime }
                )
            )
        }

        // Sort apps by highest usage time
        val sortedApps = appItems.sortedByDescending { it.totalForegroundTimeMs }
        val mostUsed = sortedApps.firstOrNull()

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateString = dateFormat.format(Date(startTime))
        val dayLabel = when (daysAgo) {
            0 -> "Today"
            1 -> "Yesterday"
            else -> SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(startTime))
        }

        return DayUsageData(
            dateString = dateString,
            dayLabel = dayLabel,
            totalScreenTimeMs = totalScreenTime,
            totalAppsUsed = sortedApps.size,
            mostUsedApp = mostUsed,
            apps = sortedApps
        )
    }

    /**
     * Fetches daily history breakdown for the last N days.
     */
    fun getDailyHistory(context: Context, daysCount: Int = 7): List<HistoryDaySummary> {
        val historyList = mutableListOf<HistoryDaySummary>()
        for (i in 0 until daysCount) {
            val dayData = getUsageForDay(context, i)
            val topApps = dayData.apps.take(3).map {
                TopAppSummary(
                    appName = it.appName,
                    packageName = it.packageName,
                    durationMs = it.totalForegroundTimeMs
                )
            }
            historyList.add(
                HistoryDaySummary(
                    dateString = dayData.dateString,
                    dayLabel = dayData.dayLabel,
                    totalScreenTimeMs = dayData.totalScreenTimeMs,
                    topApps = topApps
                )
            )
        }
        return historyList
    }

    private fun getAppName(pm: PackageManager, packageName: String): String {
        return try {
            val appInfo: ApplicationInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast('.')
        }
    }

    private fun getAppIconBase64(pm: PackageManager, packageName: String): String? {
        return try {
            val iconDrawable = pm.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(iconDrawable)
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 85, outputStream)
            val byteArray = outputStream.toByteArray()
            "data:image/png;base64," + Base64.encodeToString(byteArray, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val bitmap = if (drawable.intrinsicWidth <= 0 || drawable.intrinsicHeight <= 0) {
            Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        } else {
            Bitmap.createBitmap(
                minOf(drawable.intrinsicWidth, 144),
                minOf(drawable.intrinsicHeight, 144),
                Bitmap.Config.ARGB_8888
            )
        }
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun createEmptyDayData(startTime: Long, daysAgo: Int): DayUsageData {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateString = dateFormat.format(Date(startTime))
        val dayLabel = if (daysAgo == 0) "Today" else if (daysAgo == 1) "Yesterday" else SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(startTime))
        return DayUsageData(
            dateString = dateString,
            dayLabel = dayLabel,
            totalScreenTimeMs = 0L,
            totalAppsUsed = 0,
            mostUsedApp = null,
            apps = emptyList()
        )
    }
}
