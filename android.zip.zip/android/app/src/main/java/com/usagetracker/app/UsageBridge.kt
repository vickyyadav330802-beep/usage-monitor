package com.usagetracker.app

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.webkit.JavascriptInterface
import com.google.gson.Gson

class UsageBridge(private val activity: Activity) {

    private val gson = Gson()

    @JavascriptInterface
    fun hasUsagePermission(): Boolean {
        return UsageStatsHelper.hasUsageAccessPermission(activity)
    }

    @JavascriptInterface
    fun requestUsagePermission() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    }

    @JavascriptInterface
    fun getUsageStatsForDay(daysAgo: Int): String {
        return try {
            val data = UsageStatsHelper.getUsageForDay(activity, daysAgo)
            gson.toJson(data)
        } catch (e: Exception) {
            e.printStackTrace()
            "{}"
        }
    }

    @JavascriptInterface
    fun getDailyHistory(daysCount: Int): String {
        return try {
            val list = UsageStatsHelper.getDailyHistory(activity, daysCount)
            gson.toJson(list)
        } catch (e: Exception) {
            e.printStackTrace()
            "[]"
        }
    }

    @JavascriptInterface
    fun getAppSessionDetails(packageName: String, daysAgo: Int): String {
        return try {
            val dayData = UsageStatsHelper.getUsageForDay(activity, daysAgo)
            val app = dayData.apps.find { it.packageName == packageName }
            gson.toJson(app?.sessions ?: emptyList<UsageSession>())
        } catch (e: Exception) {
            e.printStackTrace()
            "[]"
        }
    }
}
