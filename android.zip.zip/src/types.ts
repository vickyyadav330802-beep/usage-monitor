export interface UsageSession {
  id: string;
  startTime: number; // epoch ms
  endTime: number;   // epoch ms
  durationMs: number;
}

export interface AppUsageItem {
  packageName: string;
  appName: string;
  iconBase64?: string; // base64 encoded PNG or system fallback
  totalForegroundTimeMs: number;
  lastTimeUsedMs: number;
  firstTimeUsedMs?: number;
  launchCount?: number;
  sessions: UsageSession[];
  category?: string;
}

export interface DayUsageData {
  dateString: string; // YYYY-MM-DD
  dayLabel: string;   // e.g. "Today", "Yesterday", "Tue, Aug 28"
  totalScreenTimeMs: number;
  totalAppsUsed: number;
  mostUsedApp?: AppUsageItem;
  apps: AppUsageItem[];
}

export interface HistoryDaySummary {
  dateString: string;
  dayLabel: string;
  totalScreenTimeMs: number;
  topApps: {
    appName: string;
    packageName: string;
    durationMs: number;
  }[];
}

export interface AndroidBridgeInterface {
  hasUsagePermission: () => boolean | Promise<boolean>;
  requestUsagePermission: () => void | Promise<void>;
  getUsageStatsForDay: (daysAgo: number) => string | Promise<string>; // JSON string of DayUsageData
  getDailyHistory: (days: number) => string | Promise<string>; // JSON string of HistoryDaySummary[]
  getAppSessionDetails: (packageName: string, daysAgo: number) => string | Promise<string>; // JSON string of UsageSession[]
}

declare global {
  interface Window {
    AndroidUsageStats?: AndroidBridgeInterface;
    webkit?: {
      messageHandlers?: {
        AndroidUsageStats?: {
          postMessage: (msg: unknown) => void;
        };
      };
    };
  }
}
