import { DayUsageData, HistoryDaySummary, UsageSession, AppUsageItem } from '../types';

export class AndroidBridgeService {
  /**
   * Checks whether the native Android JS interface is mounted.
   */
  static isNativeAndroid(): boolean {
    return typeof window !== 'undefined' && Boolean(window.AndroidUsageStats);
  }

  /**
   * Checks if PACKAGE_USAGE_STATS permission is granted on the Android device.
   */
  static async checkPermission(): Promise<boolean> {
    if (!this.isNativeAndroid()) {
      return false;
    }
    try {
      const res = window.AndroidUsageStats!.hasUsagePermission();
      return typeof res === 'boolean' ? res : await Promise.resolve(res);
    } catch (e) {
      console.error('Error checking Android usage permission:', e);
      return false;
    }
  }

  /**
   * Opens Android Settings -> Usage Access screen (Settings.ACTION_USAGE_ACCESS_SETTINGS).
   */
  static openSettings(): void {
    if (this.isNativeAndroid()) {
      try {
        window.AndroidUsageStats!.requestUsagePermission();
      } catch (e) {
        console.error('Error opening Android usage settings:', e);
      }
    } else {
      console.warn('Native Android bridge not available in browser environment.');
    }
  }

  /**
   * Fetches real usage stats for a given day offset (0 = today, 1 = yesterday, etc.)
   */
  static async getUsageForDay(daysAgo: number): Promise<DayUsageData | null> {
    if (!this.isNativeAndroid()) {
      return null;
    }

    try {
      const raw = window.AndroidUsageStats!.getUsageStatsForDay(daysAgo);
      const jsonStr = typeof raw === 'string' ? raw : await Promise.resolve(raw);
      if (!jsonStr) return null;
      return JSON.parse(jsonStr) as DayUsageData;
    } catch (e) {
      console.error(`Error querying Android usage stats for day ${daysAgo}:`, e);
      return null;
    }
  }

  /**
   * Fetches daily history for the past N days.
   */
  static async getDailyHistory(days: number = 7): Promise<HistoryDaySummary[]> {
    if (!this.isNativeAndroid()) {
      return [];
    }

    try {
      const raw = window.AndroidUsageStats!.getDailyHistory(days);
      const jsonStr = typeof raw === 'string' ? raw : await Promise.resolve(raw);
      if (!jsonStr) return [];
      return JSON.parse(jsonStr) as HistoryDaySummary[];
    } catch (e) {
      console.error(`Error querying Android daily history:`, e);
      return [];
    }
  }

  /**
   * Fetches detailed session events for a specific app package.
   */
  static async getAppSessions(packageName: string, daysAgo: number): Promise<UsageSession[]> {
    if (!this.isNativeAndroid()) {
      return [];
    }

    try {
      const raw = window.AndroidUsageStats!.getAppSessionDetails(packageName, daysAgo);
      const jsonStr = typeof raw === 'string' ? raw : await Promise.resolve(raw);
      if (!jsonStr) return [];
      return JSON.parse(jsonStr) as UsageSession[];
    } catch (e) {
      console.error(`Error querying session details for ${packageName}:`, e);
      return [];
    }
  }
}

/**
 * Format milliseconds into clean human-readable duration (e.g., "4h 32m", "41m", "< 1m")
 */
export function formatDuration(ms: number): string {
  if (!ms || ms < 1000) return '0m';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  if (hours > 0) {
    if (minutes > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${hours}h`;
  }
  if (minutes > 0) {
    return `${minutes}m`;
  }
  return '< 1m';
}

/**
 * Format timestamp into standard local time (e.g. "7:32 PM")
 */
export function formatTime(timestampMs: number): string {
  if (!timestampMs || timestampMs <= 0) return 'Never';
  const date = new Date(timestampMs);
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}

/**
 * Format timestamp into short date (e.g. "Mon, Oct 24")
 */
export function formatDateLabel(daysAgo: number): string {
  if (daysAgo === 0) return 'Today';
  if (daysAgo === 1) return 'Yesterday';
  
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}
