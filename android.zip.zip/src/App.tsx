import React, { useState, useEffect, useCallback } from 'react';
import { DayUsageData, HistoryDaySummary, AppUsageItem } from './types';
import { AndroidBridgeService } from './services/androidBridge';
import { Header } from './components/Header';
import { PermissionNotice } from './components/PermissionNotice';
import { ScreenTimeHero } from './components/ScreenTimeHero';
import { AppUsageList } from './components/AppUsageList';
import { AppDetailModal } from './components/AppDetailModal';
import { DailyHistoryView } from './components/DailyHistoryView';
import { NativeBuildGuideModal } from './components/NativeBuildGuideModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'today' | 'yesterday' | 'history'>('today');
  const [isNative, setIsNative] = useState<boolean>(false);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [dayData, setDayData] = useState<DayUsageData | null>(null);
  const [historyData, setHistoryData] = useState<HistoryDaySummary[]>([]);
  const [selectedAppPackage, setSelectedAppPackage] = useState<string | null>(null);
  const [showBuildGuide, setShowBuildGuide] = useState<boolean>(false);

  const loadData = useCallback(async () => {
    setIsRefreshing(true);
    const nativeAvailable = AndroidBridgeService.isNativeAndroid();
    setIsNative(nativeAvailable);

    if (!nativeAvailable) {
      // In browser preview: Usage Access is not granted because web browser sandbox cannot read OS usage
      setHasPermission(false);
      setDayData(null);
      setHistoryData([]);
      setIsLoading(false);
      setIsRefreshing(false);
      return;
    }

    const permitted = await AndroidBridgeService.checkPermission();
    setHasPermission(permitted);

    if (permitted) {
      const daysAgo = activeTab === 'yesterday' ? 1 : 0;
      const [todayResult, historyResult] = await Promise.all([
        AndroidBridgeService.getUsageForDay(daysAgo),
        AndroidBridgeService.getDailyHistory(7)
      ]);
      setDayData(todayResult);
      setHistoryData(historyResult);
    } else {
      setDayData(null);
      setHistoryData([]);
    }

    setIsLoading(false);
    setIsRefreshing(false);
  }, [activeTab]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Hook up Android onResume callback to automatically update when returning from settings
  useEffect(() => {
    (window as unknown as { onAndroidResume?: () => void }).onAndroidResume = () => {
      loadData();
    };

    return () => {
      delete (window as unknown as { onAndroidResume?: () => void }).onAndroidResume;
    };
  }, [loadData]);

  // Handle switching tabs
  const handleTabChange = (tab: 'today' | 'yesterday' | 'history') => {
    setActiveTab(tab);
  };

  const handleSelectDayFromHistory = (daysAgo: number) => {
    if (daysAgo === 0) {
      setActiveTab('today');
    } else if (daysAgo === 1) {
      setActiveTab('yesterday');
    } else {
      setActiveTab('today');
    }
  };

  const selectedAppItem: AppUsageItem | undefined =
    dayData?.apps.find((a) => a.packageName === selectedAppPackage);

  return (
    <div className="min-h-screen bg-[#F3F4F6] text-[#1F2937] flex flex-col font-sans antialiased selection:bg-[#E5E7EB]">
      <Header
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onRefresh={loadData}
        isRefreshing={isRefreshing}
        isNative={isNative}
        hasPermission={hasPermission}
        onOpenBuildGuide={() => setShowBuildGuide(true)}
      />

      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-6 sm:px-6">
        {/* Permission not granted */}
        {hasPermission === false && (
          <PermissionNotice
            isNative={isNative}
            onRefresh={loadData}
            onOpenBuildGuide={() => setShowBuildGuide(true)}
          />
        )}

        {/* Permission granted: display real data */}
        {hasPermission === true && (
          <>
            {activeTab === 'history' ? (
              <DailyHistoryView
                history={historyData}
                onSelectDay={handleSelectDayFromHistory}
              />
            ) : (
              <>
                {dayData && (
                  <>
                    <ScreenTimeHero
                      dayData={dayData}
                      onSelectApp={(pkg) => setSelectedAppPackage(pkg)}
                    />
                    <AppUsageList
                      apps={dayData.apps}
                      totalScreenTimeMs={dayData.totalScreenTimeMs}
                      onSelectApp={(pkg) => setSelectedAppPackage(pkg)}
                    />
                  </>
                )}
              </>
            )}
          </>
        )}
      </main>

      {/* App Detailed Sessions Modal */}
      {selectedAppItem && dayData && (
        <AppDetailModal
          app={selectedAppItem}
          dayLabel={dayData.dayLabel}
          totalDayScreenTimeMs={dayData.totalScreenTimeMs}
          onClose={() => setSelectedAppPackage(null)}
        />
      )}

      {/* Native Build Guide Modal */}
      {showBuildGuide && (
        <NativeBuildGuideModal onClose={() => setShowBuildGuide(false)} />
      )}
    </div>
  );
}
