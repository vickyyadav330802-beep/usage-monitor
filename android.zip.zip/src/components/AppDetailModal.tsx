import React from 'react';
import { AppUsageItem } from '../types';
import { formatDuration, formatTime } from '../services/androidBridge';
import { X, Clock, Repeat, Calendar, ArrowRight, Activity } from 'lucide-react';

interface AppDetailModalProps {
  app: AppUsageItem;
  dayLabel: string;
  totalDayScreenTimeMs: number;
  onClose: () => void;
}

export const AppDetailModal: React.FC<AppDetailModalProps> = ({
  app,
  dayLabel,
  totalDayScreenTimeMs,
  onClose
}) => {
  const percentOfTotal = totalDayScreenTimeMs > 0
    ? Math.round((app.totalForegroundTimeMs / totalDayScreenTimeMs) * 100)
    : 0;

  return (
    <div
      id="app-detail-modal-overlay"
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="app-detail-modal-card"
        className="w-full max-w-lg bg-white rounded-t-[32px] sm:rounded-[32px] shadow-2xl max-h-[88vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-200 border border-[#E5E7EB]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-[#E5E7EB] flex items-center justify-between bg-white">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#F3F4F6] border border-[#E5E7EB] flex items-center justify-center overflow-hidden shadow-2xs shrink-0">
              {app.iconBase64 ? (
                <img
                  src={app.iconBase64}
                  alt={app.appName}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="text-lg font-bold text-[#1F2937]">
                  {app.appName.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#1F2937] leading-tight">{app.appName}</h2>
              <p className="text-[11px] font-mono text-[#9CA3AF] truncate max-w-[220px]">
                {app.packageName}
              </p>
            </div>
          </div>

          <button
            id="btn-close-app-detail"
            onClick={onClose}
            className="p-2 text-[#9CA3AF] hover:text-[#1F2937] hover:bg-[#F3F4F6] rounded-2xl transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Main Stat Card (Clean Minimal Dark Card) */}
          <div className="bg-[#1F2937] text-white rounded-2xl p-5 flex items-center justify-between shadow-xs">
            <div>
              <div className="text-xs font-bold text-[#9CA3AF] uppercase tracking-wider">
                {dayLabel} Total Usage
              </div>
              <div className="text-3xl font-bold text-white mt-1">
                {formatDuration(app.totalForegroundTimeMs)}
              </div>
            </div>
            <div className="text-right">
              <span className="inline-block bg-[#374151] text-white text-xs font-bold px-3 py-1.5 rounded-full">
                {percentOfTotal}% of screen
              </span>
            </div>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB] rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#6B7280] font-medium mb-1">
                <Clock className="w-3.5 h-3.5 text-[#9CA3AF]" />
                Last Used
              </div>
              <div className="text-sm font-bold text-[#1F2937]">
                {formatTime(app.lastTimeUsedMs)}
              </div>
            </div>

            <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB] rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#6B7280] font-medium mb-1">
                <Repeat className="w-3.5 h-3.5 text-[#9CA3AF]" />
                Times Opened
              </div>
              <div className="text-sm font-bold text-[#1F2937]">
                {app.launchCount || app.sessions.length || 1} times
              </div>
            </div>
          </div>

          {/* Sessions List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-[#1F2937] uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-[#1F2937]" />
                Usage Sessions
              </h3>
              <span className="text-xs text-[#6B7280] font-mono">
                {app.sessions.length} {app.sessions.length === 1 ? 'session' : 'sessions'}
              </span>
            </div>

            {app.sessions.length === 0 ? (
              <div className="text-xs text-[#9CA3AF] italic py-4 text-center bg-[#F9FAFB] rounded-2xl border border-[#E5E7EB]">
                No discrete session intervals recorded for this period.
              </div>
            ) : (
              <div className="space-y-2">
                {app.sessions.map((session, idx) => (
                  <div
                    key={session.id || idx}
                    className="p-3 bg-[#F9FAFB] hover:bg-[#F3F4F6] border border-[#E5E7EB] rounded-2xl flex items-center justify-between text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2 font-medium text-[#4B5563]">
                      <span className="text-[#1F2937] font-semibold">{formatTime(session.startTime)}</span>
                      <ArrowRight className="w-3 h-3 text-[#9CA3AF] shrink-0" />
                      <span className="text-[#1F2937] font-semibold">{formatTime(session.endTime)}</span>
                    </div>
                    <div className="font-bold text-[#1F2937] bg-white border border-[#E5E7EB] px-2.5 py-1 rounded-lg">
                      {formatDuration(session.durationMs)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#E5E7EB] bg-white flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-[#1F2937] hover:bg-black text-white text-xs font-semibold rounded-2xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
