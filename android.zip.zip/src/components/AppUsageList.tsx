import React from 'react';
import { AppUsageItem } from '../types';
import { formatDuration, formatTime } from '../services/androidBridge';
import { ChevronRight, Clock, Repeat, Smartphone } from 'lucide-react';

interface AppUsageListProps {
  apps: AppUsageItem[];
  totalScreenTimeMs: number;
  onSelectApp: (pkgName: string) => void;
}

export const AppUsageList: React.FC<AppUsageListProps> = ({
  apps,
  totalScreenTimeMs,
  onSelectApp
}) => {
  if (apps.length === 0) {
    return (
      <div id="no-usage-data-notice" className="w-full bg-white rounded-[32px] p-8 sm:p-10 text-center text-[#6B7280] my-4 shadow-xs border border-[#E5E7EB]">
        <Smartphone className="w-8 h-8 mx-auto mb-2 text-[#9CA3AF]" />
        <h3 className="text-base font-bold text-[#1F2937]">No usage data available yet.</h3>
        <p className="text-xs text-[#6B7280] mt-1 max-w-sm mx-auto">
          Start using your applications or tap refresh to update on-device statistics.
        </p>
      </div>
    );
  }

  return (
    <section id="app-usage-list-section" className="w-full bg-white rounded-[32px] p-6 sm:p-8 shadow-xs border border-[#E5E7EB]">
      <div className="flex justify-between items-center mb-4 sm:mb-6">
        <h2 className="text-xl font-bold text-[#1F2937]">Application Usage</h2>
        <span className="text-xs font-bold text-[#6B7280] bg-[#F3F4F6] px-3 py-1 rounded-full border border-[#E5E7EB]">
          {apps.length} apps
        </span>
      </div>

      <div className="space-y-1">
        {apps.map((app, index) => {
          const percentOfTotal = totalScreenTimeMs > 0
            ? Math.round((app.totalForegroundTimeMs / totalScreenTimeMs) * 100)
            : 0;

          return (
            <button
              key={app.packageName}
              id={`app-item-${app.packageName.replace(/[^a-zA-Z0-9_-]/g, '_')}`}
              onClick={() => onSelectApp(app.packageName)}
              className="w-full text-left p-3 sm:p-3.5 rounded-2xl hover:bg-[#F9FAFB] active:bg-[#F3F4F6] transition-colors flex items-center justify-between gap-3 group"
            >
              {/* Left: App Icon & Name */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                <div className="w-11 h-11 rounded-2xl bg-[#F3F4F6] border border-[#E5E7EB] flex items-center justify-center shrink-0 overflow-hidden shadow-2xs">
                  {app.iconBase64 ? (
                    <img
                      src={app.iconBase64}
                      alt={app.appName}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="text-base font-bold text-[#4B5563]">
                      {app.appName.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#1F2937] truncate">
                      {app.appName}
                    </span>
                    <span className="text-[10px] font-mono text-[#9CA3AF] bg-[#F3F4F6] px-1.5 py-0.5 rounded-md shrink-0">
                      #{index + 1}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-[#6B7280] mt-0.5">
                    <span className="flex items-center gap-1 truncate">
                      <Clock className="w-3 h-3 text-[#9CA3AF] shrink-0" />
                      Last: {formatTime(app.lastTimeUsedMs)}
                    </span>
                    {app.launchCount !== undefined && app.launchCount > 0 && (
                      <span className="flex items-center gap-1 shrink-0">
                        <Repeat className="w-3 h-3 text-[#9CA3AF]" />
                        {app.launchCount} {app.launchCount === 1 ? 'open' : 'opens'}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right: Usage Duration & Percent */}
              <div className="flex items-center gap-3 shrink-0 text-right">
                <div>
                  <div className="text-sm sm:text-base font-bold text-[#1F2937]">
                    {formatDuration(app.totalForegroundTimeMs)}
                  </div>
                  <div className="text-xs text-[#9CA3AF] font-mono">
                    {percentOfTotal}%
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#D1D5DB] group-hover:text-[#4B5563] transition-colors" />
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
