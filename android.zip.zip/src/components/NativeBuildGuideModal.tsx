import React from 'react';
import { X, Smartphone, Terminal, CheckCircle2, ShieldAlert } from 'lucide-react';

interface NativeBuildGuideModalProps {
  onClose: () => void;
}

export const NativeBuildGuideModal: React.FC<NativeBuildGuideModalProps> = ({ onClose }) => {
  return (
    <div
      id="native-build-guide-overlay"
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="native-build-guide-card"
        className="w-full max-w-xl bg-white rounded-[32px] shadow-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 border border-[#E5E7EB]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-5 border-b border-[#E5E7EB] flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#F3F4F6] border border-[#E5E7EB] text-[#1F2937] flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1F2937]">Run on Real Android Device</h2>
              <p className="text-[11px] text-[#6B7280] font-medium">Build instructions for Android APK</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#9CA3AF] hover:text-[#1F2937] hover:bg-[#F3F4F6] rounded-2xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-xs text-[#4B5563] leading-relaxed">
          <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB] rounded-2xl text-[#1F2937] flex items-start gap-3">
            <CheckCircle2 className="w-4 h-4 text-[#059669] shrink-0 mt-0.5" />
            <p>
              The full native Kotlin project is ready in the <code className="font-mono bg-[#E5E7EB] px-1.5 py-0.5 rounded text-[#1F2937]">/android</code> directory. It uses real <code className="font-mono bg-[#E5E7EB] px-1.5 py-0.5 rounded text-[#1F2937]">UsageStatsManager</code> and <code className="font-mono bg-[#E5E7EB] px-1.5 py-0.5 rounded text-[#1F2937]">UsageEvents</code> without synthetic data.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold text-[#1F2937] uppercase tracking-wider mb-2">
              1. Build with Android Studio
            </h3>
            <ol className="list-decimal list-inside space-y-1.5 text-[#6B7280] pl-1">
              <li>Open Android Studio and click <strong>Open Project</strong>.</li>
              <li>Select the <code className="font-mono bg-[#F3F4F6] px-1.5 py-0.5 rounded text-[#1F2937]">/android</code> folder in this repository.</li>
              <li>Click <strong>Build &gt; Build APK(s)</strong>.</li>
              <li>Transfer <code className="font-mono bg-[#F3F4F6] px-1.5 py-0.5 rounded text-[#1F2937]">app-debug.apk</code> to your phone and install.</li>
            </ol>
          </div>

          <div>
            <h3 className="text-xs font-bold text-[#1F2937] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-[#1F2937]" />
              2. Build via Gradle Command Line
            </h3>
            <div className="bg-[#1F2937] text-gray-100 font-mono text-[11px] p-3.5 rounded-2xl space-y-1">
              <p className="text-[#9CA3AF]"># Build Android debug APK</p>
              <p>cd android</p>
              <p>./gradlew assembleDebug</p>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold text-[#1F2937] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-[#D97706]" />
              3. Granting Usage Access on Your Phone
            </h3>
            <ol className="list-decimal list-inside space-y-1 text-[#6B7280] pl-1">
              <li>Launch <strong>Usage Monitor</strong> on your Android phone.</li>
              <li>Tap <strong>Grant Usage Access</strong>.</li>
              <li>Android Settings will open. Toggle <strong>Permit usage access</strong> to ON.</li>
              <li>Return to the app — your actual device usage will display immediately.</li>
            </ol>
          </div>
        </div>

        <div className="p-4 border-t border-[#E5E7EB] bg-white flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-[#1F2937] hover:bg-black text-white text-xs font-semibold rounded-2xl transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
