import React from 'react';
import { Lock, Settings, Smartphone, ExternalLink, Shield } from 'lucide-react';
import { AndroidBridgeService } from '../services/androidBridge';

interface PermissionNoticeProps {
  isNative: boolean;
  onRefresh: () => void;
  onOpenBuildGuide: () => void;
}

export const PermissionNotice: React.FC<PermissionNoticeProps> = ({
  isNative,
  onRefresh,
  onOpenBuildGuide
}) => {
  const handleGrantPermission = () => {
    if (isNative) {
      AndroidBridgeService.openSettings();
    } else {
      onOpenBuildGuide();
    }
  };

  return (
    <div id="permission-notice-container" className="w-full max-w-xl mx-auto p-8 sm:p-10 bg-white rounded-[32px] shadow-xs border border-[#E5E7EB] text-center my-6">
      <div className="w-14 h-14 bg-[#F3F4F6] border border-[#E5E7EB] rounded-2xl flex items-center justify-center mx-auto mb-5 text-[#1F2937]">
        <Lock className="w-6 h-6 text-[#1F2937]" />
      </div>

      <h2 id="permission-notice-title" className="text-xl sm:text-2xl font-bold text-[#1F2937] mb-2 tracking-tight">
        Usage Access Permission Required
      </h2>

      <p className="text-sm text-[#6B7280] mb-6 max-w-md mx-auto leading-relaxed">
        To read real screen time, foreground app sessions, and app launch counts, Android requires
        explicit user authorization under System Usage Access.
      </p>

      <div className="space-y-3">
        <button
          id="btn-grant-usage-access"
          onClick={handleGrantPermission}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#1F2937] hover:bg-black active:bg-black text-white text-sm font-semibold rounded-2xl transition-all shadow-xs"
        >
          <Settings className="w-4 h-4" />
          Grant Usage Access
        </button>

        <div>
          <button
            id="btn-check-permission-again"
            onClick={onRefresh}
            className="text-xs font-semibold text-[#6B7280] hover:text-[#1F2937] underline underline-offset-4 py-1.5 transition-colors"
          >
            I already granted access, check again
          </button>
        </div>
      </div>

      {!isNative && (
        <div id="web-runtime-explanation" className="mt-8 pt-6 border-t border-[#E5E7EB] text-left">
          <div className="flex items-start gap-3 p-4 bg-[#F9FAFB] border border-[#E5E7EB] rounded-2xl">
            <Smartphone className="w-5 h-5 text-[#1F2937] shrink-0 mt-0.5" />
            <div className="text-xs text-[#4B5563] space-y-1.5">
              <p className="font-bold text-[#1F2937]">Real Android Hardware Required</p>
              <p className="leading-relaxed">
                Standard web browsers cannot access OS-level Android <code className="bg-[#E5E7EB] px-1.5 py-0.5 rounded text-[11px] font-mono text-[#1F2937]">UsageStatsManager</code> APIs directly due to browser sandboxing.
              </p>
              <p className="leading-relaxed">
                This project includes the complete native Kotlin Android source code in <code className="bg-[#E5E7EB] px-1.5 py-0.5 rounded text-[11px] font-mono text-[#1F2937]">/android</code>. Build the APK and install it on your real phone to inspect your live on-device statistics.
              </p>
              <button
                onClick={onOpenBuildGuide}
                className="inline-flex items-center gap-1 font-bold text-[#1F2937] hover:underline mt-1"
              >
                View APK Build Instructions <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
