import React from 'react';
import { HistoryDaySummary } from '../types';
import { formatDuration } from '../services/androidBridge';
import { Calendar, BarChart3, TrendingUp, ChevronRight } from 'lucide-react';

interface DailyHistoryViewProps {
  history: HistoryDaySummary[];
  onSelectDay: (daysAgo: number) => void;
}

export const DailyHistoryView: React.FC<DailyHistoryViewProps> = ({ history, onSelectDay }) => {
  if (history.length === 0) {
    return (
      <div className="w-full bg-white rounded-[32px] p-8 sm:p-10 text-center text-[#6B7280] my-4 shadow-xs border border-[#E5E7EB]">
        <Calendar className="w-8 h-8 mx-auto mb-2 text-[#9CA3AF]" />
        <h3 className="text-base font-bold text-[#1F2937]">No history data available yet.</h3>
        <p className="text-xs text-[#6B7280] mt-1">
          Historical usage will appear as you continue using your applications.
        </p>
      </div>
    );
  }

  // Calculate max usage time for relative bar height scaling
  const maxUsageMs = Math.max(...history.map((h) => h.totalScreenTimeMs), 1000 * 60 * 60); // min 1h scale
  const totalWeekMs = history.reduce((acc, h) => acc + h.totalScreenTimeMs, 0);
  const avgDailyMs = Math.round(totalWeekMs / Math.max(1, history.length));

  return (
    <div id="daily-history-view" className="space-y-6">
      {/* 7-Day Overview & Chart Dark Card */}
      <section className="bg-[#1F2937] text-white rounded-[32px] p-6 sm:p-8 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#9CA3AF]" />
              7-Day Activity
            </h2>
            <p className="text-xs text-[#9CA3AF] mt-0.5">
              Daily average: <span className="font-semibold text-white">{formatDuration(avgDailyMs)}</span>
            </p>
          </div>
        </div>

        {/* Minimalist Bar Chart */}
        <div className="h-44 flex items-end justify-between gap-2.5 pt-6 pb-2 px-1">
          {history.map((item, index) => {
            const heightPercent = Math.max(8, Math.round((item.totalScreenTimeMs / maxUsageMs) * 100));
            const isToday = index === 0;

            return (
              <button
                key={item.dateString}
                onClick={() => onSelectDay(index)}
                className="flex-1 flex flex-col items-center gap-2 group h-full justify-end"
                title={`${item.dayLabel}: ${formatDuration(item.totalScreenTimeMs)}`}
              >
                <span className="text-[10px] font-mono text-[#9CA3AF] opacity-0 group-hover:opacity-100 transition-opacity">
                  {formatDuration(item.totalScreenTimeMs)}
                </span>
                <div className="w-full max-w-[36px] bg-[#374151] rounded-t-lg overflow-hidden flex flex-col justify-end h-full">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-lg transition-all ${
                      isToday
                        ? 'bg-white group-hover:bg-[#F3F4F6]'
                        : 'bg-[#9CA3AF] group-hover:bg-white'
                    }`}
                  />
                </div>
                <span
                  className={`text-[11px] font-bold truncate ${
                    isToday ? 'text-white font-black' : 'text-[#9CA3AF]'
                  }`}
                >
                  {item.dayLabel.slice(0, 3)}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Day by Day Breakdown List */}
      <section className="bg-white rounded-[32px] p-6 sm:p-8 shadow-xs border border-[#E5E7EB]">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <h3 className="text-xl font-bold text-[#1F2937]">Daily Breakdown</h3>
          <span className="text-xs font-bold text-[#6B7280] bg-[#F3F4F6] px-3 py-1 rounded-full border border-[#E5E7EB]">
            7 days
          </span>
        </div>

        <div className="space-y-1">
          {history.map((day, index) => (
            <button
              key={day.dateString}
              onClick={() => onSelectDay(index)}
              className="w-full text-left p-3.5 sm:p-4 rounded-2xl hover:bg-[#F9FAFB] active:bg-[#F3F4F6] transition-colors flex items-center justify-between gap-4 group"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-[#1F2937]">{day.dayLabel}</span>
                  <span className="text-xs text-[#9CA3AF] font-mono">{day.dateString}</span>
                </div>

                {/* Top Apps Preview */}
                {day.topApps && day.topApps.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-1.5 mt-1.5 text-xs text-[#6B7280]">
                    <span className="text-[#9CA3AF] font-medium text-[11px]">Top:</span>
                    {day.topApps.map((app, i) => (
                      <span
                        key={app.packageName + i}
                        className="bg-[#F3F4F6] px-2 py-0.5 rounded-md text-[#4B5563] font-medium text-[11px]"
                      >
                        {app.appName} ({formatDuration(app.durationMs)})
                      </span>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-[#9CA3AF] mt-1">No recorded app sessions</div>
                )}
              </div>

              <div className="text-right shrink-0 flex items-center gap-3">
                <div>
                  <div className="text-sm sm:text-base font-bold text-[#1F2937]">
                    {formatDuration(day.totalScreenTimeMs)}
                  </div>
                  <span className="text-xs text-[#6B7280] font-medium group-hover:text-[#1F2937]">View &rarr;</span>
                </div>
                <ChevronRight className="w-4 h-4 text-[#D1D5DB] group-hover:text-[#4B5563] transition-colors" />
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
