import React from 'react';
import { DayUsageData } from '../types';
import { formatDuration } from '../services/androidBridge';
import { Flame, Layers, Clock, TrendingUp } from 'lucide-react';

interface ScreenTimeHeroProps {
  dayData: DayUsageData;
  onSelectApp: (pkgName: string) => void;
}

export const ScreenTimeHero: React.FC<ScreenTimeHeroProps> = ({ dayData, onSelectApp }) => {
  const totalMs = dayData.totalScreenTimeMs;
  const totalSeconds = Math.floor(totalMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  const mostUsed = dayData.mostUsedApp;

  // Clean, high-contrast monochrome & accent palette matching Clean Utility theme
  const barColors = [
    '#1F2937', // Dark slate
    '#4B5563', // Charcoal gray
    '#9CA3AF', // Cool gray
    '#059669', // Emerald accent
    '#D97706', // Amber accent
    '#6366F1', // Indigo accent
  ];

  const topAppsForBar = dayData.apps.slice(0, 5);
  const remainingTime = Math.max(
    0,
    totalMs - topAppsForBar.reduce((acc, app) => acc + app.totalForegroundTimeMs, 0)
  );

  return (
    <section id="screen-time-hero" className="w-full bg-white rounded-[32px] p-6 sm:p-8 shadow-xs border border-[#E5E7EB] mb-6">
      <div className="flex flex-col items-center text-center">
        <span className="text-[#6B7280] text-xs font-bold uppercase tracking-widest mb-2">
          {dayData.dayLabel}'s Total
        </span>

        {/* Large Total Usage Number with Clean Minimal Typography */}
        <div id="total-usage-time" className="text-6xl sm:text-7xl font-light tracking-tighter text-[#1F2937] mb-4">
          {hours > 0 ? (
            <>
              {hours}h <span className="text-4xl sm:text-5xl text-[#9CA3AF] font-light">{minutes}m</span>
            </>
          ) : (
            <>
              {minutes} <span className="text-4xl text-[#9CA3AF] font-light">min</span>
            </>
          )}
        </div>

        {/* Minimal Progress Bar / Distribution Line */}
        <div className="w-full bg-[#F3F4F6] h-2.5 rounded-full mb-6 overflow-hidden flex gap-0.5 p-0.5">
          {totalMs > 0 ? (
            <>
              {topAppsForBar.map((app, index) => {
                const percent = Math.max(1, (app.totalForegroundTimeMs / totalMs) * 100);
                return (
                  <div
                    key={app.packageName}
                    style={{
                      width: `${percent}%`,
                      backgroundColor: barColors[index % barColors.length]
                    }}
                    className="h-full rounded-full transition-all"
                    title={`${app.appName}: ${formatDuration(app.totalForegroundTimeMs)} (${percent.toFixed(0)}%)`}
                  />
                );
              })}
              {remainingTime > 0 && (
                <div
                  style={{
                    width: `${(remainingTime / totalMs) * 100}%`,
                    backgroundColor: '#E5E7EB'
                  }}
                  className="h-full rounded-full"
                  title={`Other apps: ${formatDuration(remainingTime)}`}
                />
              )}
            </>
          ) : (
            <div className="w-0 h-full" />
          )}
        </div>

        {/* Grid Stats */}
        <div className="grid grid-cols-2 gap-4 w-full text-left">
          <div className="bg-[#F9FAFB] p-4 sm:p-5 rounded-2xl border border-[#F3F4F6] flex flex-col justify-between">
            <div className="text-2xl font-semibold text-[#1F2937] tracking-tight">{dayData.totalAppsUsed}</div>
            <div className="text-xs text-[#6B7280] font-medium mt-1">Apps Used</div>
          </div>

          {mostUsed ? (
            <button
              onClick={() => onSelectApp(mostUsed.packageName)}
              className="bg-[#F9FAFB] hover:bg-[#F3F4F6] p-4 sm:p-5 rounded-2xl border border-[#F3F4F6] transition-colors flex flex-col justify-between group text-left"
            >
              <div className="text-2xl font-semibold text-[#1F2937] truncate max-w-full tracking-tight">
                {mostUsed.appName}
              </div>
              <div className="text-xs text-[#6B7280] font-medium mt-1 flex items-center justify-between">
                <span>Most Used</span>
                <span className="font-bold text-[#1F2937]">{formatDuration(mostUsed.totalForegroundTimeMs)}</span>
              </div>
            </button>
          ) : (
            <div className="bg-[#F9FAFB] p-4 sm:p-5 rounded-2xl border border-[#F3F4F6] flex flex-col justify-between">
              <div className="text-2xl font-semibold text-[#9CA3AF] tracking-tight">—</div>
              <div className="text-xs text-[#6B7280] font-medium mt-1">Most Used</div>
            </div>
          )}
        </div>

        {/* Distribution Legend */}
        {topAppsForBar.length > 0 && totalMs > 0 && (
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 mt-5 text-xs">
            {topAppsForBar.map((app, index) => (
              <div key={app.packageName} className="flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-full shrink-0"
                  style={{ backgroundColor: barColors[index % barColors.length] }}
                />
                <span className="font-medium text-[#4B5563] truncate max-w-[120px]">{app.appName}</span>
                <span className="text-[#9CA3AF] font-mono text-[11px]">
                  {Math.round((app.totalForegroundTimeMs / totalMs) * 100)}%
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
