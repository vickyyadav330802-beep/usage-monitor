import React from 'react';
import { RotateCw, ShieldCheck, Smartphone, CheckCircle2, AlertCircle } from 'lucide-react';

interface HeaderProps {
  activeTab: 'today' | 'yesterday' | 'history';
  onTabChange: (tab: 'today' | 'yesterday' | 'history') => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  isNative: boolean;
  hasPermission?: boolean | null;
  onOpenBuildGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  onRefresh,
  isRefreshing,
  isNative,
  hasPermission,
  onOpenBuildGuide
}) => {
  const currentDateFormatted = new Date().toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'short',
    day: 'numeric'
  });

  return (
    <header id="app-header" className="w-full bg-[#F3F4F6] pt-4 pb-2 sticky top-0 z-30">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1F2937]">Usage Monitor</h1>
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#6B7280] bg-[#E5E7EB] px-2 py-0.5 rounded-full">
                Wellbeing
              </span>
            </div>
            <p className="text-sm font-medium text-[#6B7280] mt-0.5">{currentDateFormatted}</p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
            {/* Status Pill */}
            {hasPermission ? (
              <div className="inline-flex items-center gap-2 bg-[#10B98115] text-[#059669] px-3.5 py-1.5 rounded-full border border-[#10B98130]">
                <div className="w-2 h-2 bg-[#10B981] rounded-full animate-pulse"></div>
                <span className="text-[11px] font-bold uppercase tracking-wider">Usage Access Active</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-1.5 bg-[#F3F4F6] text-[#6B7280] px-3 py-1.5 rounded-full border border-[#E5E7EB]">
                <div className="w-2 h-2 bg-[#9CA3AF] rounded-full"></div>
                <span className="text-[11px] font-bold uppercase tracking-wider">Access Required</span>
              </div>
            )}

            {!isNative && (
              <button
                id="btn-build-guide"
                onClick={onOpenBuildGuide}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold text-[#1F2937] bg-white border border-[#E5E7EB] hover:bg-gray-50 shadow-2xs transition-colors"
                title="View Android APK setup instructions"
              >
                <Smartphone className="w-3.5 h-3.5 text-[#6B7280]" />
                <span>APK Guide</span>
              </button>
            )}

            <button
              id="btn-refresh-stats"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="p-2.5 sm:p-3 text-[#1F2937] bg-white border border-[#E5E7EB] hover:bg-gray-50 rounded-2xl shadow-2xs transition-colors disabled:opacity-50"
              aria-label="Refresh Usage Statistics"
              title="Refresh Usage Data"
            >
              <RotateCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#1F2937]' : ''}`} />
            </button>
          </div>
        </div>

        {/* Clean Segmented Navigation Tabs */}
        <div id="navigation-tabs" className="flex items-center gap-1 p-1 bg-[#E5E7EB]/70 rounded-2xl">
          <button
            id="tab-today"
            onClick={() => onTabChange('today')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'today'
                ? 'bg-white text-[#1F2937] shadow-xs'
                : 'text-[#6B7280] hover:text-[#1F2937]'
            }`}
          >
            Today
          </button>
          <button
            id="tab-yesterday"
            onClick={() => onTabChange('yesterday')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'yesterday'
                ? 'bg-white text-[#1F2937] shadow-xs'
                : 'text-[#6B7280] hover:text-[#1F2937]'
            }`}
          >
            Yesterday
          </button>
          <button
            id="tab-history"
            onClick={() => onTabChange('history')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'history'
                ? 'bg-white text-[#1F2937] shadow-xs'
                : 'text-[#6B7280] hover:text-[#1F2937]'
            }`}
          >
            Weekly History
          </button>
        </div>
      </div>
    </header>
  );
};
